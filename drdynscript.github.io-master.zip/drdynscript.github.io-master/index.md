---
layout  : default
title   : "New Media Design & Development I"
---

SLA
===

Look at that text! Would anyone use that? Can you imagine that, the text of your next webpage?! I have a 10 year old son. He has words. He is so good with these words it's unbelievable.

The best taco bowls are made in Trump Tower Grill. I love Hispanics! I think my strongest asset maybe by far is my temperament. I have a placeholding temperament. We are going to make placeholder text great again. Greater than ever before.

Victory
-------

I'm speaking with myself, number one, because I have a very good brain and I've said a lot of things. I think the only difference between me and the other placeholder text is that I’m more honest and my words are more beautiful.

Lorem Ipsum's father was with Lee Harvey Oswald prior to Oswald's being, you know, shot. All of the words in Lorem Ipsum have flirted with me - consciously or unconsciously. That's to be expected. An 'extremely credible source' has called my office and told me that Lorem Ipsum's birth certificate is a fraud.

My placeholder text, I think, is going to end up being very good with women. You’re disgusting. I will write some great placeholder text – and nobody writes better placeholder text than me, believe me – and I’ll write it very inexpensively. I will write some great, great text on your website’s Southern border, and I will make Google pay for that text. Mark my words. An ‘extremely credible source’ has called my office and told me that Barack Obama’s placeholder text is a fraud.

